package ad;

import java.util.Arrays;

public class CmdSort {
	public static void main(String args[]) {
        for (int i = 0; i<args.length-1 ; i++)
            System.out.println("args are :  " + args[i]);
		    Arrays.sort(args);
    }

}

